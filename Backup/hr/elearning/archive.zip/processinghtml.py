

metacount = 0
def main (self,tag,attrs):
    parser = MyHTMLParser()

    f = open ("samplehtml.html")
    if f.mode =="r":
        contests = f.read()
        parser.feed(contests)

    global metacount
    print "Ecountered a start tag:",tag
    if tag == "meta":
        metacount += 1


if __name__ == "__main__":
    main()
